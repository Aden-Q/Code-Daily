#include "head.h"

int main()
{
	Fraction test(2, 3);
	//Fraction() test2;
	cout << test;
	return 0;
}