/*
Author: ***
Group: ***
*/

#include "polygon.h"

int main()
{
    int N, n; //n:6-10, N:6-300
    int i, j;
    float cur_area, last_area;
    float max_area = 0;
    coordinate Points_clockwise; //cyclic list
    coordinate *CurPoint, *root, *last;
    coordinate *n_gon[11], *max_n_gon[11]; //array of points
    coordinate point;                      //read coordinate from standard in
    vector<coordinate> Points;             //store the coordinate of each point in N-gon
    vector<coordinate>::iterator iter;
    cin >> N;
    cin >> n;
    for (i = 0; i < N; i++)
    {
        cin >> point.x;
        cin >> point.y;
        point.indice = i;
        Points.push_back(point);
    }
    Clockwise(Points, N);
    for (iter = Points.begin(); (iter + 1) != Points.end(); iter++)
        (*iter).next = &(*(iter + 1));
    (*iter).next = &(Points[0]);
    root = &(Points[0]);
    CurPoint = root;
    for (i = 0; i < n; i++) //select initial n points (in clockwise)
    {
        n_gon[i] = CurPoint;
        CurPoint = CurPoint->next;
    }
    cur_area = Calarea(n_gon, n);
    last_area = cur_area;
    Print_info(n_gon, max_area, cur_area, last_area, n); //print information
    if (last_area > max_area)
    {
        max_area = last_area;
        for (i = 0; i < n; i++) //store points in max_n_gon
            max_n_gon[i] = n_gon[i];
    }

    while (true)
    {
        while (true)
        {
            last = n_gon[n-1];
            n_gon[n-1] = n_gon[n-1]->next;
            cur_area = Calarea(n_gon, n);
            Print_info(n_gon, max_area, cur_area, last_area, n); //print information
            if (cur_area < last_area) //can't be updated, so end "while" loop
            {
                n_gon[n-1] = last; //not change
                break;
            }
            else        //if the last point can be updated, then accept the change and update others except the first one
            {
                last_area = cur_area;       //update last_area
                if (last_area > max_area){   //update max_area
                    max_area = last_area;
                    for (i = 0; i < n; i++) 
                        max_n_gon[i] = n_gon[i];
                }
                for (j = n - 2; j >= 1; j--)
                {
                    while(true)
                    {
                        last = n_gon[j];
                        n_gon[j] = n_gon[j]->next;
                        cur_area = Calarea(n_gon, n);
                        Print_info(n_gon, max_area, cur_area, last_area, n); //print information
                        if (cur_area < last_area)                  //can't be updated, so end "while" loop
                        {
                            n_gon[j] = last; //not change
                            break;
                        }
                        else
                        {
                            last_area = cur_area;    //update max_area and store points in n_gon
                            if(last_area>max_area){
                                max_area = last_area;
                                for (i = 0; i < n; i++) //store points in max_n_gon
                                    max_n_gon[i] = n_gon[i];
                            }
                        }
                    }
                }
            }
        }
        n_gon[0] = n_gon[0]->next;
        if (n_gon[0] == root) //traversal completed
            break;
        else
        {
            for (i = 1; i < n; i++)
            {
                if (n_gon[i] == n_gon[i - 1])
                    n_gon[i] = n_gon[i]->next;
            }
            cur_area = Calarea(n_gon, n);
            last_area = cur_area;
            Print_info(n_gon, max_area, cur_area, last_area, n); //print information
            if (max_area < last_area)
            {
                max_area = last_area;    //update max_area and store points in n_gon
                for (i = 0; i < n; i++) //store points in max_n_gon
                    max_n_gon[i] = n_gon[i];
            }
        }
    }

    cout<<endl;
    for(i=0;i<n;i++)
        cout<<max_n_gon[i]->indice<<" ";
    cout<<endl;
    cout << max_area << endl;

    return 0;
}

float Calarea(coordinate *n_gon[], int n)
{
    float area;
    float total_area = 0;
    coordinate *a, *b, *c;
    int i, j, k;
    i = 0;
    j = 1;
    k = 2;
    a = n_gon[i];
    b = n_gon[j];
    c = n_gon[k];
    while (k != n)
    {
        area = abs(1.0 / 2 * (a->x * (b->y - c->y) + b->x * (c->y - a->y) + c->x * (a->y - b->y)));
        total_area += area;
        j++;
        k++;
        b = n_gon[j];
        c = n_gon[k];
    }
    return total_area;
}

void Clockwise(vector<coordinate> &Points, int N)
{
    vector<coordinate>::iterator iter;
    vector<coordinate> UpPoints, DownPoints;
    float y_sum, y_mid;
    y_sum = 0;
    for (iter = Points.begin(); iter != Points.end(); iter++)
        y_sum += (*iter).y;
    y_mid = y_sum / N;
    for (iter = Points.begin(); iter != Points.end(); iter++)
    {
        if ((*iter).y >= y_mid)
            UpPoints.push_back(*iter); //above midline
        else
            DownPoints.push_back(*iter); //below midline
    }
    sort(UpPoints.begin(), UpPoints.end(), comparison_ascend);
    sort(DownPoints.begin(), DownPoints.end(), comparison_descend);
    Points.clear();
    for (iter = UpPoints.begin(); iter != UpPoints.end(); iter++)
        Points.push_back(*iter);
    for (iter = DownPoints.begin(); iter != DownPoints.end(); iter++)
        Points.push_back(*iter);
}

bool comparison_ascend(coordinate a, coordinate b)
{
    return a.x < b.x;
}

bool comparison_descend(coordinate a, coordinate b)
{
    return a.x > b.x;
}

void Print_info(coordinate *gon[], float max_area, float cur_area, float last_area, int n)
{
    int i;
    cout << "max: " << max_area << " cur: " << cur_area << " last: " << last_area << endl;
    for (i = 0; i < n; i++)
        cout << gon[i]->indice << " ";
    cout << endl;
}