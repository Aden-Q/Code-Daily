/*
Author: ***
Group: ***
*/
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

struct coordinate{
    float x;
    float y;
    int indice;
    coordinate* next;
};

float Calarea(coordinate *n_gon[], int n);  //calculate area of a 3-gon
void Clockwise(vector<coordinate> &Points, int N);
bool comparison_ascend(coordinate a, coordinate b);
bool comparison_descend(coordinate a, coordinate b);
void Print_info(coordinate *gon[], float max_area, float cur_area, float last_area, int n);