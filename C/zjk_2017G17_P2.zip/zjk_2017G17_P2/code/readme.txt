The project origins from the problem of red-black tree and it check if a binary tree is a 
red-black tree or not.
Compile and execute:
Dev-Cpp VC6++ are better choices when compiling and exeuting, other IDEs may also work well 
but errors may occur due to platform tool set and the operating system. Using Dev-Cpp, you 
can simply open the source code, compile and run it. 
The code has passed through the test on PAT so its accuracy can be confirmed. The program has
the function of tip to avoid trouble for users.
First, you should input 'K', which denotes the number of trees you want to test.
Second, you are about to input 'N', the total number of nodes of one tree.
Then N datas follows, and the datas should conform to preorder traversal.
After that, you should input iteration time.(because the time of program running once is 
too small to measure, the iteration time is necessary)
The principle of program can be achieved in the document, so it is omitted in this text.
