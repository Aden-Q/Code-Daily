1.Double click  zjk_2017G17_P1.c to open the source code file
2.Choose one of the four functions
3.Find compile and run buttom in menu bar of your compiler, click to execute it
4.Input 8 as repetitions
5.Input 100 twice as n, m respectively
6.Input a suitable number k as repetitions of function calls(the recommended value is no more than 100000)
7.Repeat step 5&6, n, m replaced with 500, 800, ����, 10000
8.Change a function to test until four are all done

